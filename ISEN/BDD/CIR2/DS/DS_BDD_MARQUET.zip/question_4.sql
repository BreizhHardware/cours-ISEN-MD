SELECT comment_text AS "commentaires" FROM comments
                                      WHERE user_id = 37;