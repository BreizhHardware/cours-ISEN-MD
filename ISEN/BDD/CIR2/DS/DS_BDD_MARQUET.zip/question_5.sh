#!/bin/bash
psql -U tester -d postgres -f ./question_5_1.sql